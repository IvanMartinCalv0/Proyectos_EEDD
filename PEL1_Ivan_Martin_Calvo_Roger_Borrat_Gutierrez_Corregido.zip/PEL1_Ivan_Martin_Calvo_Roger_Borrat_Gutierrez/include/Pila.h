#ifndef PILA_H
#define PILA_H
#include "NodoPila.h"
#include "Automovil.h"

class Pila
{
    private:
    pnodo cima;

    public:
    Pila();
    ~Pila();
    bool esVacia();
    void apilar(Automovil v);
    void desapilar();
    Automovil verCima();  //Devuelve la cima
    int contar();  //Devuelve el numero de elementos que tenga la pila
    void muestra_Pila();

};
#endif // PILA_H

