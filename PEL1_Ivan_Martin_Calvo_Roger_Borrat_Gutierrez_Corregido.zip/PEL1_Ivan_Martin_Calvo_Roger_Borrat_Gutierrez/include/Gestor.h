#ifndef GESTOR_H
#define GESTOR_H
#include "Automovil.h"
#include "Cola.h"
#include "Zona_de_Reparto.h"
#include"Pila.h"

class Gestor
{
    friend class Automovil;
    public:
        Gestor();
        virtual ~Gestor();
        int getNv();
        int getNs();
        int getNp();
        int getNc();
        void setNv(int);  //Asigna el numero de vehiculos
        void setNs(int);  //Asigna el numero de vehiculos que se sacan de la cola de fabrica
        void inicio_simulacion();  //Comienza la simulacion
        Cola getColafabrica();
        Zona_de_Reparto cargar_camiones();
        void avanzar_simulacion(Zona_de_Reparto*);  //Avanza un paso de la simulacion
        void vaciar_Colafab();  //Vacia la cola de fabrica
        void zona_avanzar_simulacion(); //Selecciona de forma aleatoria la zona a la que se envian los vehiculos
        void simulacion_completa(); //Realiza la simulacion hasta el final
        void mostrar_Zonas();

    private:
        //Constantes
        int NV=20, NS=5,NP=10, NC=10;
        Cola cola_fabrica;
        Zona_de_Reparto N;
        Zona_de_Reparto O;
        Zona_de_Reparto S;
        Zona_de_Reparto E;

};

#endif // GESTOR_H
