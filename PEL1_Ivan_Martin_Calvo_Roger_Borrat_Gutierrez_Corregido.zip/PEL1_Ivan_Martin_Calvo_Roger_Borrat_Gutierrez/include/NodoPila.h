#ifndef NODOPILA_H
#define NODOPILA_H
#include <iostream>
#include "Automovil.h"

class NodoPila
{
    private:
    Automovil valor;
    NodoPila *siguiente;
    friend class Pila;
    public:
    NodoPila();
    NodoPila(Automovil v, NodoPila *sig = NULL);
    ~NodoPila();
};
typedef NodoPila *pnodo;
#endif // NODOPILA_H
