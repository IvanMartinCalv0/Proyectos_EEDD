#ifndef COLA_H
#define COLA_H
#include "NodoCola.h"
#include "Automovil.h"

class Cola
{
    private:
        NodoCola * primero;
        NodoCola * ultimo;
        int longitud;
    public:
        Cola();
        ~Cola();
        void encolar(Automovil);
        Automovil inicio();  //Devuelve el inicio de la cola
        void desencolar();
        bool es_vacia();
        int contar(); //Similar a get_longitud()
        void muestra_Cola();
};
#endif // COLA_H
