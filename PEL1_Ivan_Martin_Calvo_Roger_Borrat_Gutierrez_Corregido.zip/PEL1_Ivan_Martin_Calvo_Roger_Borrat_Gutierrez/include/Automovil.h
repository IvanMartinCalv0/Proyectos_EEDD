#ifndef AUTOMOVIL_H
#define AUTOMOVIL_H


class Automovil
{

    public:
        Automovil();
        virtual ~Automovil();
        void asignarColor(); //Asigna el color de forma aleatoria
        void asignarModelo();  //Asigna el modelo de forma aleatoria
        void asignarConces();  //Asigna el concesionario de forma aleatoria
        void asignarBastidor();  //Asigna el bastidor de forma aleatoria
        void muestra();  //Muestra todos los datos del vehiculo para poder hacer testeos
        void muestraColor(); //Muestra el color
        void muestraModelo(); //Muestra el Modelo
        void muestraBastidor();  //Muestra el bastidor
        void muestraConces();  //Muestra el concesionario

    private:
        int conces;
        char n_bastidor[10];
        char modelo[40];
        char color[40];

};

#endif // AUTOMOVIL_H
