#ifndef NODOCOLA_H
#define NODOCOLA_H
#include <iostream>
#include "Automovil.h"

class NodoCola
{

    friend class Cola;
    private:
        NodoCola *siguiente;
        Automovil elemento;
    public:
        NodoCola();
        NodoCola(Automovil e, NodoCola*sig = NULL);
        ~NodoCola();

};
#endif // NODOCOLA_H
