#include "NodoPila.h"
#include "Automovil.h"

NodoPila::NodoPila()
{
    Automovil a;
    valor=a;
    siguiente=NULL;
    //ctor
}

NodoPila::NodoPila(Automovil v, NodoPila *sig)
{
    valor = v;
    siguiente = sig;
}

NodoPila::~NodoPila()
{
    //dtor
}
