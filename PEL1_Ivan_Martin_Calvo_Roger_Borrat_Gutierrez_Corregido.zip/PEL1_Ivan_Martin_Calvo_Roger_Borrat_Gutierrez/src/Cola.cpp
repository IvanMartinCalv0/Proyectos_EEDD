#include "Cola.h"
#include "NodoPila.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
using namespace std;

Cola::Cola()
{
    primero = NULL; ultimo = NULL;
    longitud = 0;
}
Cola::~Cola() { }


void Cola::encolar(Automovil elemento)
{
    NodoCola *nuevo_nodo = new
    NodoCola(elemento);
    if(es_vacia()){
        primero = nuevo_nodo;
        ultimo = nuevo_nodo;
    }else{
        ultimo->siguiente = nuevo_nodo;
        ultimo = nuevo_nodo;
        }
        longitud++;
}

void Cola::desencolar()
{
    if(!es_vacia()){
        Automovil elemento = primero->elemento;
        NodoCola *aux = primero;
        if((primero == ultimo) && (primero->siguiente == NULL)){
            primero = NULL;
            ultimo = NULL;
            aux->siguiente = NULL;
            delete(aux);
        }else{
            primero = primero->siguiente;
            aux->siguiente = NULL;
            delete(aux);
        }
        longitud--;

    }
}

Automovil Cola::inicio()
{
    if(!es_vacia()){
        return primero->elemento;
        }
}


bool Cola::es_vacia()
{
    return ((primero == NULL) && (ultimo ==NULL));
}





int Cola::contar()
{
    int i;
    if(es_vacia()){
       return 0;
    }else{
        Automovil x= inicio();
        desencolar();
        if(es_vacia()){
            i= 1;
        }else{
            i=(1+contar());
        }
        encolar(x);
        return i;
    }


}

void Cola::muestra_Cola()
{
   if(!es_vacia()){
        Automovil a = inicio();
        cout<<"Automovil de datos: \n"<<"   ";a.muestraBastidor();cout<<"\n"<<"   ";a.muestraColor();cout<<"\n"<<"   ";a.muestraModelo();cout<<"\n"<<"   Concesionario: ";a.muestraConces();cout<<"\n";
        desencolar();
        muestra_Cola();
        encolar(a);
   }
}

