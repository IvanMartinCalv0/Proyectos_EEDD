#include "NodoCola.h"
#include "Automovil.h"

NodoCola::NodoCola()
{
    Automovil a;
    elemento=a;
    siguiente=NULL;
    //constructor por defecto
}

NodoCola::NodoCola(Automovil e, NodoCola*sig )
{
    elemento = e;
    siguiente = sig;
}

NodoCola::~NodoCola()
{
//dtor
}
