#include <iostream>
#include <string>
#include <stdexcept>
#include "Zona_de_Reparto.h"
using namespace std;
Zona_de_Reparto::Zona_de_Reparto()
{
    //ctor
}

Zona_de_Reparto::~Zona_de_Reparto()
{
    //dtor
}


Cola Zona_de_Reparto::getColaZ()
{
    return cola_zona;
}

Pila Zona_de_Reparto::getCamion1()
{
    return camion1;
}
Pila Zona_de_Reparto::getCamion2()
{
    return camion2;
}

void Zona_de_Reparto::cargar_camion(int n, Cola* c, int cam)
{   Automovil aut;
    if(cam==1){
        for(int i=0;i<n;i++){
            aut=c->inicio();
            camion1.apilar(aut);
            c->desencolar();
        }
    }else if(cam==2){
        for(int i=0;i<n;i++){
            aut=c->inicio();
            camion2.apilar(aut);
            c->desencolar();
        }
    }
}

void Zona_de_Reparto::descargar_camion()
{
    Automovil aut;
    while(!(camion1.esVacia()) ){
        aut=camion1.verCima();
        aut.asignarConces();
        cola_zona.encolar(aut);
        camion1.desapilar();
    }
    while(!(camion2.esVacia()) ){
        aut=camion2.verCima();
        aut.asignarConces();
        cola_zona.encolar(aut);
        camion2.desapilar();

    }
}

void Zona_de_Reparto::mostrar_Zona()
{
    cout<<"Registro de zona: \n";
    cout<<"En el almacen: \n";
    cola_zona.muestra_Cola();
    cout<<"Camion 1: \n";
    camion1.muestra_Pila();
    cout<<"Camion 2: \n";
    camion2.muestra_Pila();
    cout<<"----------------------------"<<endl;
}
