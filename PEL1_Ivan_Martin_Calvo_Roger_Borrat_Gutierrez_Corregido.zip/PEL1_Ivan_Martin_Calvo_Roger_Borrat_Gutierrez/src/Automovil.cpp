#include "Automovil.h"
#include "Gestor.h""
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>>
#include <time.h>

using namespace std;


Automovil::Automovil()
{
    asignarColor();
    asignarModelo();
    asignarBastidor();
    conces= 0;
}

Automovil::~Automovil()
{
    //dtor
}


void Automovil::asignarColor()
{
    int n = rand()%6;
    switch (n) {
        case 0: strcpy(color,"Rojo");
        break;
        case 1: strcpy(color,"Azul");
        break;
        case 2: strcpy(color,"Blanco");
        break;
        case 3: strcpy(color,"Negro");
        break;
        case 4: strcpy(color,"Gris");
        break;
        case 5: strcpy(color,"Amarillo");
        break;}

}

void Automovil::asignarModelo()
{
    int n = rand()%6;
    switch (n) {
        case 0: strcpy(modelo,"Honda Civic");
        break;
        case 1: strcpy(modelo,"Volkswagen Polo");
        break;
        case 2: strcpy(modelo,"Renault Laguna");
        break;
        case 3: strcpy(modelo,"Seat Panda");
        break;
        case 4: strcpy(modelo,"Fiat 500");
        break;
        case 5: strcpy(modelo,"Mercedes Vito");
        break;}
}

void Automovil::asignarBastidor()
{
    string letra= "abcdefghijklmnopqrstuvwxyz";
    string num= "0123456789";
    string res= "";
    for(int i=0;i<5;i++){
        int n = rand()%26;
        res+= letra[n];
    }
    for(int j=0;j<3;j++){
        int n = rand()%10;
        res += num[n];
    }
    strcpy(n_bastidor,res.c_str()); //Asigna el resultado a la variable del objeto
}

void Automovil::asignarConces()
{
    Gestor g;
    int n = 1 + rand()%(g.getNc());
    conces = n;
}

void Automovil::muestraConces()
{
    cout<<conces;
}

void Automovil::muestra()
{
    cout<<n_bastidor<<endl;
    cout<<conces<<endl;
    cout<<color<<endl;
    cout<<modelo<<endl;
}
void Automovil::muestraBastidor()
{
   cout<<n_bastidor;
}

void Automovil::muestraModelo()
{
    cout<<modelo;
}

void Automovil::muestraColor()
{
    cout<<color;
}

