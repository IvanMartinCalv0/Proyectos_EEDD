#include "Gestor.h"
using namespace std;

Gestor::Gestor()
{
    //ctor
}

Gestor::~Gestor()
{
    //dtor
}

int Gestor::getNv()
{
    return NV;
}

int Gestor::getNs()
{
    return NS;
}

int Gestor::getNp()
{
    return NP;
}

int Gestor::getNc()
{
    return NC;
}

Cola Gestor::getColafabrica()
{
    return cola_fabrica;
}

void Gestor::inicio_simulacion()
{
    for(int i=0;i<NV;i++){
        Automovil a;
        cola_fabrica.encolar(a);
    }
}

void Gestor::setNv(int n)
{
        NV=n;

}

void Gestor::setNs(int n)
{
        NS=n;

}

void Gestor::avanzar_simulacion(Zona_de_Reparto* z)
{
    Automovil aut;
   if((z->camion1.contar()<NP || z->camion2.contar()<NP) && cola_fabrica.contar()<NS){  //Si caben mas automoviles en los camiones pero no hay suficientes vehiculos en la cola de fabrica como para poder realizar su traspaso

    cout<<"No hay suficientes automoviles en la fabrica para llenar los camiones, inicie de nuevo la simulacion"<<endl;

   }else if (z->camion1.contar()==NP && z->camion2.contar()==NP){  //Si los camiones estan llenos los pasa al almacen de zona
            z->descargar_camion();

    }
    else if(z->camion1.contar()==NP){  //Si el camion1 esta lleno carga el 2
        if(!(z->camion2.contar()==NP)){
            if((NS+z->camion2.contar())>NP){ //Carga los automoviles que falten para llenarlo
                z->cargar_camion(NP-z->camion2.contar(), &cola_fabrica, 2);
            }else{
                 z->cargar_camion(NS, &cola_fabrica, 2);
             }
        }
    }
   else{
        if((z->camion1.contar()<NP)){
                if((NS+z->camion1.contar())>NP){  //Carga los automoviles que falten para llenarlo
                    z->cargar_camion(NP-z->camion1.contar(), &cola_fabrica, 1);
                }else{
                     z->cargar_camion(NS, &cola_fabrica, 1);

                 }
        }
   }


   //cout <<cola_fabrica.contar()<<" "<<z->camion1.contar()<<" "<<z->camion2.contar()<<" "<<z->cola_zona.contar()<<endl;  //Para testeo
}
void Gestor::vaciar_Colafab()  //Vacia la cola de la fabrica
{
    while(!cola_fabrica.es_vacia()){
        cola_fabrica.desencolar();
    }
}


void Gestor::zona_avanzar_simulacion()
{
    int zona = rand() % 4; //Asigna una zona aleatoria
    switch(zona){
        case 0:cout<<"Enviado a la zona N"<<endl;
               avanzar_simulacion(&N);
        break;
        case 1:cout<<"Enviado a la zona O"<<endl;
               avanzar_simulacion(&O);
        break;
        case 2:cout<<"Enviado a la zona S"<<endl;
               avanzar_simulacion(&S);
        break;
        case 3:cout<<"Enviado a la zona E"<<endl;
               avanzar_simulacion(&E);
        break;
    }

}

void Gestor::mostrar_Zonas()
{
    cout<<"Zona de Reparto: N  \n";
    N.mostrar_Zona();
    cout<<"Zona de Reparto: S  \n";
    S.mostrar_Zona();
    cout<<"Zona de Reparto: E  \n";
    E.mostrar_Zona();
    cout<<"Zona de Reparto: O  \n";
    O.mostrar_Zona();
}

void Gestor::simulacion_completa()
{
    int n_sim=1;
    while (!(cola_fabrica.es_vacia())){
        cout<<"Paso de la simulacion numero: "<<n_sim<<endl;
        n_sim+=1;
        int zona = rand() % 4;  //Asigna una zona aleatoria
        switch(zona){
            case 0:cout<<"Enviado a la zona N"<<endl;
                   avanzar_simulacion(&N);
                   N.mostrar_Zona();
            break;
            case 1:cout<<"Enviado a la zona O"<<endl;
                   avanzar_simulacion(&O);
                   O.mostrar_Zona();
            break;
            case 2:cout<<"Enviado a la zona S"<<endl;
                   avanzar_simulacion(&S);
                   S.mostrar_Zona();
            break;
            case 3:cout<<"Enviado a la zona E"<<endl;
                   avanzar_simulacion(&E);
                   E.mostrar_Zona();
            break;
        }
        cout<<"Los vehiculos que estan en la fabrica todavia son: "<<endl;
        cola_fabrica.muestra_Cola();

   }
}

