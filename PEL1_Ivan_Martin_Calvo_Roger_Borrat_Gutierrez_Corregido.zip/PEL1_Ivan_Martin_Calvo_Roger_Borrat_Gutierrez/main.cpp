#include <iostream>
#include <string>
#include <stdexcept>
#include "Cola.h"
#include "Pila.h"
#include "Zona_de_Reparto.h"
#include "Automovil.h"
#include "Gestor.h"
using namespace std;



bool check(string v)  //Codigo que  verifica si se puede convertir a Int
{
    bool verificar=true;
    for(int i=0; i< v.length() ;i++){
        if(!isdigit(v[i])){
           return false;
        }
    }
    return verificar;
}

int main()
{
    //Creamos las objetos necesarios, 1 Gestor y 4 Zonas de reparto
    Gestor g;

    //Imprime las opciones del menu
    cout<<"1. Generar aleatoriamente la cola de automoviles disponibles en la fabrica con NV automoviles." << endl << "2. Generar aleatoriamente la cola de automoviles disponibles en la fabrica solicitando NV por pantalla."<<endl<<
    "3. Mostrar en pantalla los datos de la cola de automoviles disponibles en la fabrica."<<endl<<"4. Borrar la cola de automoviles disponibles en la f�brica. "<<endl<<
    "5. Avanzar un paso en la simulacion. "<<endl<<
    "6. Avanzar un paso en la simulacion, solicitando NS por pantalla."<<endl<<
    "7. Mostrar en pantalla los datos de los almacenes de zona y registro o cola_zona"<<endl<<"8. Realizar la simulacion hasta finalizar los automoviles disponibles. En cada uno de los pasos se mostraran en pantalla los datos de la cola de fabrica y de cada una de las zonas de reparto."
    <<endl<<"0. Salir."<<endl;

    string num;
    int contador=0;  //Utilizado para limitar las opciones del menu dependiendo de como se desarroye la simulacion
    int n;

    do{
        try{
            cout<<"Escoja una opcion del menu: "<<endl;
            cin>>num;
            if(!check(num)){ //Lanza una excepcion si no se ha introducido un numero
                throw invalid_argument("Opcion no encontrada en el menu");
            }else{
                n= stoi(num);
            }
            fflush(stdin); //Borra el buffer
            }catch (exception& er)
            {
                cout<<er.what()<<endl;
                fflush(stdin);
            }
            if(contador == 0){
                switch(n){
                    case 0: break;
                    case 1: g.inicio_simulacion();  //Inicia la simulacion
                            contador+=1;

                    break;
                    case 2: int nv;
                            do{//Verifica la entrada del usuario
                                string numv;
                                try{
                                    cout<<"Indique un numero de vehiculos entre 10 y 30"<<endl;
                                    cin>>numv;
                                    if(!check(numv)){
                                        throw invalid_argument("Valor no valido");
                                    }else if ((stoi(numv)<10)||((stoi(numv)>30))){
                                        throw invalid_argument("Valor no valido");
                                    }else{
                                        nv=stoi(numv);
                                    }
                                    g.setNv(nv);  //Cambia el valor de Nv
                                    g.inicio_simulacion();  //Inicia la simulacion
                                    }catch (exception& e)
                                    {
                                        cout<<e.what()<<endl;
                                        fflush(stdin);

                                    }

                            }while((nv<10)||(nv>30));
                             contador+=1;
                        break;
                        default: cout<<"Debe realizar primero una de las opciones 1 o 2"<<endl;
                    }

            }else{
                switch(n){
                    case 0: break;
                    case 1: g.inicio_simulacion();  //Inicia la simulacion

                    break;
                    case 2: int nv;
                            do{ //Verifica la entrada del usuario
                                string numv;
                                try{
                                    cout<<"Indique un numero de vehiculos entre 10 y 30"<<endl;
                                    cin>>numv;
                                    if(!check(numv)){
                                        throw invalid_argument("Valor no valido");
                                    }else if ((stoi(numv)<10)||((stoi(numv)>30))){
                                        throw invalid_argument("Valor no valido");
                                    }else{
                                        nv=stoi(numv);
                                    }
                                    g.setNv(nv);  //Cambia el valor de Nv
                                    g.inicio_simulacion();  //Inicia la simulacion
                                    }catch (exception& e)
                                    {
                                        cout<<e.what()<<endl;
                                        fflush(stdin);

                                    }

                            }while((nv<10)||(nv>30));
                    break;
                    case 3:g.getColafabrica().muestra_Cola();
                    break;
                    case 4:contador-=1;
                           g.vaciar_Colafab();
                    break;
                    case 5:g.zona_avanzar_simulacion();
                    break;
                    case 6:int ns;
                            do{  //Verifica la entrada del usuario
                                string nums;
                                try{
                                    cout<<"Indique un numero de vehiculos entre 3 y 8"<<endl;
                                    cin>>nums;
                                    if(!check(nums)){
                                        throw invalid_argument("Valor no valido");
                                    }else if ((stoi(nums)<3)||((stoi(nums)>8))){
                                        throw invalid_argument("Valor no valido");
                                    }else{
                                        ns=stoi(nums);
                                    }
                                    g.setNs(ns);
                                    g.zona_avanzar_simulacion();
                                    }catch (exception& e)
                                    {
                                        cout<<e.what()<<endl;
                                        fflush(stdin);

                                    }

                            }while((ns<3)||(ns>8));

                    break;
                    case 7:  g.mostrar_Zonas();
                    break;
                    case 8: g.simulacion_completa();
                            contador-=1;
                    break;
                    default: cout<<"Escoja un valor entre 0 y 8"<<endl;

                }
            }

    }while(n!=0);


    return 0;
}



