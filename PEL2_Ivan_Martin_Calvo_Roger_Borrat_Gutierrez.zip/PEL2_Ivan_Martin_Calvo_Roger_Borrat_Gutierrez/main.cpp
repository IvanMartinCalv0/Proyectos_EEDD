#include <iostream>
#include <string>
#include <stdexcept>
#include "Cola.h"
#include "Pila.h"
#include "Zona_de_Reparto.h"
#include "Automovil.h"
#include "Gestor.h"
using namespace std;


int main()
{
    //Creamos las objetos necesarios, 1 Gestor y 4 Zonas de reparto
    Gestor g;

    //Imprime las opciones del menu
    cout<<"1. Generar aleatoriamente NV autom�viles y a�adirlos a la cola de fabrica." << endl << "2. Generar aleatoriamente la cola de automoviles disponibles en la fabrica solicitando NV por pantalla."<<endl<<
    "3. Mostrar en pantalla los datos de la cola de automoviles disponibles en la fabrica."<<endl<<"4. Borrar la cola de automoviles disponibles en la fabrica. "<<endl<<
    "5. Generar aleatoriamente pedido "<<endl<<
    "6. Leer de teclado los datos de tantos pedidos como desee el usuario, e insertarlos en la lista de pedidos."<<endl<<
    "7. Mostrar en pantalla los datos de la lista de pedidos."<<endl<<"8. Borrar la lista de pedidos."<<endl<<"9. Avanzar un paso en la simulacion."<<endl<<"10. Avanzar un paso en la simulacion solicitando NS."<<
    endl<<"11. Realiza la simulacion completa " << endl<<"12. Mostrar en pantalla los datos de la nave de reparto" << endl<<"13. Almacenar en el arbol un automovil pasado por teclado."<<endl<<"14. Almacenar en el arbol los datos de una de las colas de zona."
    <<endl<<"15. Almacenar en el arbol los datos de todas las colas de zona."<<endl<<"16. Visualizar los datos del arbol ordenados por concesionario."<<endl<<"18. Visualiza los automoviles entregados en el concesionario que se indique."
    <<endl<<"19. Visualizar el concesionario y zona del vehiculo de bastidor dado."
    <<endl<<"20. Salir."<<endl;

    int n;
  //LAS FUNCIONES 9 Y 14 ESTAN DESHABILITADAS YA QUE CAUSAN EL ERROR DEL CODIGO
    do{
            cout<<"Escoja una opcion del menu: "<<endl;
            cin>>n;

                switch(n){
                    case 20: break;
                    case 1: g.inicio_simulacion();  //Inicia la simulacion

                    break;
                    case 2: int nv;
                            cout<<"Indique un numero de vehiculos entre 10 y 30"<<endl;
                            cin>>nv;
                            g.setNv(nv);  //Cambia el valor de Nv
                            g.generar_automoviles_ModCol();  //Inicia la simulacion

                    break;
                    case 3:g.mostrar_ColaF();
                    break;
                    case 4:g.vaciar_Colafab();
                    break;
                    case 5:g.generar_pedidos();
                    break;
                    case 6:int np;
                           cout<<"Indique un numero de pedidos a realizar"<<endl;
                           cin>>np;
                           g.pedir_coches(np);

                    break;
                    case 7: g.mostrar_pedidos();
                    break;
                    case 8: g.vaciar_ListaPedidos();

                    break;
                    /*case 9: g.zona_avanzar_simulacion(); g.mostrar_Zonas_simpl();
                    break;*/
                    case 10:int ns;
                            cout<<"Indique un NS entre 4 y 8"<<endl;
                            cin>>ns;
                            g.setNs(ns);  //Cambia el valor de Nv
                            g.zona_avanzar_simulacion();  //Inicia la simulacion
                            g.mostrar_Zonas_simpl();
                    break;
                    case 11:g.simulacion_completa();
                    break;
                    case 12: g.mostrar_Zonas();
                    break;
                    case 13: g.auto_por_teclado();
                    break;
                    /*case 14:    char z ;
                                cout<<"Introduzca la zona (N,S,O,E): ";
                                cin>> z;
                                cout<<endl;
                                g.zona_a_arbol(z);
                    break;*/
                    case 15: g.zonas_a_arbol();
                    break;
                    case 16: g.mostrarAbb();
                    break;
                    case 17:char mod[3];
                            cout<<"Determina el modelo que desees borrar: "<<endl;
                            cin>>mod;
                            g.borrado_mod(mod);
                    break;
                    case 18:int num_c;
                            cout<<"Determina el concesionario que desea encontrar: "<<endl;
                            cin>>num_c;
                            g.mostrar_conces(num_c);
                    break;
                    case 19:char bas[10];
                            cout<<"Inserte el numero de bastidor que necesita (5 letras y 3 numeros) : "<<endl;
                            cin>>bas;
                            g.mostrar_por_bastidor(bas);
                    break;
                    default: cout<<"Escoja un valor entre 1 y 20"<<endl;

                }


    }while(n!=20);


    return 0;
}



