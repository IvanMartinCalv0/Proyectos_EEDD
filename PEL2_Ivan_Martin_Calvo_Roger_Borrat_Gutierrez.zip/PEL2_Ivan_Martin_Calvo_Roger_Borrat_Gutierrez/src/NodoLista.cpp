#include "NodoLista.h"

NodoLista::NodoLista(Pedido e, NodoLista *sig)
{
            elemento = e;
            siguiente = sig;

}

NodoLista::~NodoLista()
{
    //dtor
}
