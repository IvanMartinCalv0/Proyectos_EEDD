#include "Pila.h"
using namespace std;

Pila::Pila()
{cima = NULL;}



Pila::~Pila(){
    while(cima) desapilar();
    }

bool Pila::esVacia(){
    return cima == NULL;
    }

void Pila::apilar(Automovil v){
    pnodo nuevo = new NodoPila(v,cima);
    //comienzo de la pila nevo nodo
    cima = nuevo;
}

void Pila::desapilar()
{   pnodo nodo; //puntero aux para manipular el nodo
    if(cima)
        nodo = cima;
        cima = nodo->siguiente;
        delete nodo;
}


Automovil Pila::verCima()
{
    if(esVacia()){
        cout << "Pila vacia"<<endl;
    }else{
        return cima->valor;
    }

}

int Pila::contar()
{
    int i;
    if(esVacia()){
       return 0;
    }else{
        Automovil x= verCima();
        desapilar();
        if(esVacia()){
            i= 1;
        }else{
            i= (1+contar());
        }
        apilar(x);
        return i;
    }


}

void Pila::muestra_Pila()
{
   if(!esVacia()){
        Automovil a = verCima();
        cout<<"Automovil de datos: \n"<<"   ";a.muestraBastidor();cout<<"\n"<<"   ";a.muestraColor();cout<<"\n"<<"   ";a.muestraModelo();cout<<"\n"<<"   Concesionario: ";a.muestraConces();cout<<"\n";
        desapilar();
        muestra_Pila();
        apilar(a);
   }
}

