#include "Lista_Aut.h"
#include "NodoLista_Aut.h"
#include <iostream>
#include <string.h>
using namespace std;

Lista_Aut::Lista_Aut()
{
    primero = NULL;
    ultimo = NULL;
    longitud = 0;
}

Lista_Aut::~Lista_Aut()
{
}

int Lista_Aut::get_longitud()
{
	return longitud;
}

void Lista_Aut::insertar_izquierda(Automovil elemento)
{
	NodoLista_Aut *nuevo_nodo = new NodoLista_Aut(elemento);

	if(es_vacia())
	{
		primero = nuevo_nodo;
		ultimo = nuevo_nodo;
		longitud++;
	}
	else
	{
		nuevo_nodo->siguiente = primero;
		primero = nuevo_nodo;
		longitud++;
	}
}

void Lista_Aut::insertar_derecha(Automovil elemento)
{
	NodoLista_Aut *nuevo_nodo = new NodoLista_Aut(elemento);

	if(es_vacia())
	{
		primero = nuevo_nodo;
		ultimo = nuevo_nodo;
		longitud++;
	}
	else
	{
		ultimo->siguiente = nuevo_nodo;
		ultimo = nuevo_nodo;
		longitud++;
	}
}

void Lista_Aut::insertar_enPosicion(int posicion, Automovil elemento)
{
	if((posicion >=1) && (posicion <= (longitud + 1)))
	{
		if(posicion == 1)
		{
			insertar_izquierda(elemento);
		}
		else if(posicion == (longitud + 1))
		{
			insertar_derecha(elemento);
		}
		else
		{
			NodoLista_Aut *aux = primero;
			NodoLista_Aut *nuevo_nodo = new NodoLista_Aut(elemento);

			for(int i = 1; i < posicion-1; i++)
			{
				aux = aux->siguiente;
			}

			nuevo_nodo->siguiente = aux->siguiente;
			aux->siguiente = nuevo_nodo;

			longitud++;
		}
	}
}

Automovil Lista_Aut::ver_primero()
{
	if(!es_vacia())
	{
		return primero->elemento;
	}
}

Automovil Lista_Aut::ver_ultimo()
{
	if(!es_vacia())
	{
		return ultimo->elemento;
	}
}

Automovil Lista_Aut::ver_posicion(int posicion)
{
	if(!es_vacia())
	{
		NodoLista_Aut *aux = primero;

		for(int i = 1; i < posicion; i++)
		{
			aux = aux->siguiente;
		}

		return aux->elemento;
	}
}



bool Lista_Aut::es_vacia()
{
	return ((primero == NULL) && (ultimo == NULL));
}

void Lista_Aut::borrar_izquierda()
{
	if(!es_vacia())
	{
		NodoLista_Aut *aux = primero;

		if(longitud == 1)
		{
        	primero = NULL;
			ultimo = NULL;
			delete aux;
			longitud--;
		}
		else
		{
			primero = primero->siguiente;
			aux->siguiente = NULL;
			delete aux;
			longitud--;
		}


	}
}


void Lista_Aut::borrar_posicion(int posicion)
{
    //(posicion<1) || (posicion>longitud)
	if  (es_vacia()) {cout<<"No existe la posici�n"<<endl;}
	else {

		if(posicion == 1)
		{
            borrar_izquierda();
		}

		else
		{
			NodoLista_Aut *aux = primero;

			for(int i = 1; i <posicion-1; i++)
			{
				aux = aux->siguiente;
			}
			NodoLista_Aut *borrar=aux->siguiente;
			if (borrar->siguiente==NULL) {ultimo=aux;}

			aux->siguiente = borrar->siguiente;

			borrar->siguiente = NULL;

			delete borrar;
			longitud--;
		}

	}
}

void Lista_Aut::vaciar_lista()
{
	if(!es_vacia())
	{
		borrar_izquierda();
		return vaciar_lista();
	}
}


void Lista_Aut::mostrar()
{
    int i=1;
    while(i<=get_longitud()){
        cout<<"Automovil "<<i<<":"<<endl;
        ver_posicion(i).muestra();
        i++;
    }
}

bool Lista_Aut::esta_por_bastidor(char bas[10])
{
    bool sigue=false;
    int i=1;
    while(i<=get_longitud() && !sigue){
        Automovil a = ver_posicion(i);
        if(strcmp(a.getBastidor().c_str(),bas)==0){
            sigue=true;
        }else{
            i++;
        }
    }
    return sigue;
}

void Lista_Aut::borrado_m(char k[3], int j)
{
    if(j>=1){
        Automovil a = ver_posicion(j);
        if(strcmp(a.getModelo().c_str(),k)==0){
            borrar_posicion(j);
        }borrado_m(k, j-1);
    }
}
