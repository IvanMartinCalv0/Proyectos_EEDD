#include "Concesionario.h"

Concesionario::Concesionario()
{
    //ctor
}

Concesionario::~Concesionario()
{
    //dtor
}

void Concesionario::setN(int k)
{
    n = k;
}

void Concesionario::setZona(char k)
{
    zona = k;
}

Lista_Aut Concesionario::getLista()
{
    return lista;
}

char Concesionario::getZona()
{
    return zona;
}

int Concesionario::getN()
{
    return n;
}

void Concesionario::ver_Concesionario() //Muestra los datos de la lista del concesionario
{
    cout<<"Concesionario de numero: "<< n <<endl<<"----------------------------------"<<endl<<"Automoviles: "<<endl;
    lista.mostrar();
}

void Concesionario::insertar_lista(Automovil a) //A�ade el automovil a la lista
{
    lista.insertar_derecha(a);
}

void Concesionario::setLista(Lista_Aut l)
{
    lista = l;
}

void Concesionario::borrar_mod_deLista(char i[3])
{
    lista.borrado_m(i, lista.get_longitud());
}
