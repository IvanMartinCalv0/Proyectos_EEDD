#include "Lista.h"
#include "NodoLista.h"
#include <iostream>
#include <string.h>
#include <stdio.h>
using namespace std;

Lista::Lista()
{
    primero = NULL;
    ultimo = NULL;
    longitud = 0;
}

Lista::~Lista()
{
}

int Lista::get_longitud()
{
	return longitud;
}

void Lista::insertar_izquierda(Pedido elemento)
{
	NodoLista *nuevo_nodo = new NodoLista(elemento);

	if(es_vacia())
	{
		primero = nuevo_nodo;
		ultimo = nuevo_nodo;
		longitud++;
	}
	else
	{
		nuevo_nodo->siguiente = primero;
		primero = nuevo_nodo;
		longitud++;
	}
}

void Lista::insertar_derecha(Pedido elemento)
{
	NodoLista *nuevo_nodo = new NodoLista(elemento);

	if(es_vacia())
	{
		primero = nuevo_nodo;
		ultimo = nuevo_nodo;
		longitud++;
	}
	else
	{
		ultimo->siguiente = nuevo_nodo;
		ultimo = nuevo_nodo;
		longitud++;
	}
}

void Lista::insertar_enPosicion(int posicion, Pedido elemento)
{
	if((posicion >=1) && (posicion <= (longitud + 1)))
	{
		if(posicion == 1)
		{
			insertar_izquierda(elemento);
		}
		else if(posicion == (longitud + 1))
		{
			insertar_derecha(elemento);
		}
		else
		{
			NodoLista *aux = primero;
			NodoLista *nuevo_nodo = new NodoLista(elemento);

			for(int i = 1; i < posicion-1; i++)
			{
				aux = aux->siguiente;
			}

			nuevo_nodo->siguiente = aux->siguiente;
			aux->siguiente = nuevo_nodo;

			longitud++;
		}
	}
}

Pedido Lista::ver_primero()
{
	if(!es_vacia())
	{
		return primero->elemento;
	}
}

Pedido Lista::ver_ultimo()
{
	if(!es_vacia())
	{
		return ultimo->elemento;
	}
}

Pedido Lista::ver_posicion(int posicion)
{
	if(!es_vacia())
	{
		NodoLista *aux = primero;

		for(int i = 1; i < posicion; i++)
		{
			aux = aux->siguiente;
		}

		return aux->elemento;
	}
}

int Lista::pos_auto(Automovil a)
{
    int i = 1;
    bool sigue = false;
    while(i<get_longitud() && !sigue){
        Pedido aux = ver_posicion(i);
        char col1[2]; strcpy(col1,aux.getColor().c_str());
        char col2[2]; strcpy(col2,a.getColor().c_str());
        char mod1[2]; strcpy(mod1,aux.getModelo().c_str());
        char mod2[2]; strcpy(mod2,a.getModelo().c_str());
        if((strcmp(col1 ,col2)==0)&&(strcmp(mod1,mod2)==0)){
            sigue = true;
        }else{
            i+=1;
        }
    }
    return i;
}

bool Lista::esta(Automovil a)
{
    int i = 1;
    bool sigue = false;
    while(i<get_longitud() && !sigue){
        ver_posicion(i);
        char col1[3]; strcpy(col1,ver_posicion(i).getColor().c_str());
        char col2[3]; strcpy(col2,a.getColor().c_str());
        char mod1[3]; strcpy(mod1,ver_posicion(i).getModelo().c_str());
        char mod2[3]; strcpy(mod2,a.getModelo().c_str());
        if((strcmp(col1 ,col2)==0)&&(strcmp(mod1,mod2)==0)){
            sigue = true;
        }else{
            i+=1;
        }
    }
    return sigue;
}

Pedido Lista::buscar_auto(Automovil a)
{
    return ver_posicion(pos_auto(a));
}
bool Lista::es_vacia()
{
	return ((primero == NULL) && (ultimo == NULL));
}

void Lista::borrar_izquierda()
{
	if(!es_vacia())
	{
		NodoLista *aux = primero;

		if(longitud == 1)
		{
        	primero = NULL;
			ultimo = NULL;
			delete aux;
			longitud--;
		}
		else
		{
			primero = primero->siguiente;
			aux->siguiente = NULL;
			delete aux;
			longitud--;
		}


	}
}


void Lista::borrar_posicion(int posicion)
{
    //(posicion<1) || (posicion>longitud)
	if  (es_vacia()) {cout<<"No existe la posici�n"<<endl;}
	else {

		if(posicion == 1)
		{
            borrar_izquierda();
		}

		else
		{
			NodoLista *aux = primero;

			for(int i = 1; i <posicion-1; i++)
			{
				aux = aux->siguiente;
			}
			NodoLista *borrar=aux->siguiente;
			if (borrar->siguiente==NULL) {ultimo=aux;}

			aux->siguiente = borrar->siguiente;

			borrar->siguiente = NULL;

			delete borrar;
			longitud--;
		}

	}
}

void Lista::vaciar_lista()
{
	if(!es_vacia())
	{
		borrar_izquierda();
		return vaciar_lista();
	}
}

int Lista::contarPrior()
{
    int i;
    if(es_vacia()){
        return 0;
    }else{
        Pedido aux;
        if(ver_primero().getTipo()){
            aux = ver_primero();
            borrar_izquierda();
            i = 1 + contarPrior();
            insertar_izquierda(aux);
            return i;
        }else{
            return 0;
        }
    }

}

void Lista::insertar_porPrioridad(Pedido p)
{
    if(p.getTipo()){
        insertar_enPosicion(contarPrior()+1,p);
    }else{
        insertar_derecha(p);
    }
}

void Lista::todoPrior()
{
    int i = contarPrior();
    while(i < get_longitud()){
        ver_posicion(i).volverPrior();
        i+=1;
    }
}

void Lista::muestra_Lista()
{
   for(int i = 1; i<= get_longitud(); i++){
        cout<<"Pedido de datos: \n"<<"   ";ver_posicion(i).muestraModelo();cout<<"\n"<<"   ";ver_posicion(i).muestraColor();cout<<"\n"<<"   ";ver_posicion(i).muestraZona();cout<<"\n"<<"   Concesionario: ";ver_posicion(i).muestraConces();cout<<"\n"<<"   ";ver_posicion(i).muestraTipo();cout<<"\n";
   }
}
