#include "Automovil.h"
#include "Gestor.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <time.h>

using namespace std;


Automovil::Automovil()
{
    asignarColor();
    asignarModelo();
    asignarBastidor();
    conces= 0;
}

Automovil::~Automovil()
{
    //dtor
}


void Automovil::asignarColor()
{
    int n = rand()%6;
    switch (n) {
        case 0: strcpy(color,"M1");
        break;
        case 1: strcpy(color,"M2");
        break;
        case 2: strcpy(color,"M3");
        break;
        case 3: strcpy(color,"M4");
        break;
        case 4: strcpy(color,"M5");
        break;
        }

}

void Automovil::asignarModelo()
{
    int n = rand()%6;
    switch (n) {
        case 0: strcpy(modelo,"C1");
        break;
        case 1: strcpy(modelo,"C2");
        break;
        case 2: strcpy(modelo,"C3");
        break;
        }
}

void Automovil::asignarBastidor()
{
    string letra= "abcdefghijklmnopqrstuvwxyz";
    string num= "0123456789";
    string res= "";
    for(int i=0;i<5;i++){
        int n = rand()%26;
        res+= letra[n];
    }
    for(int j=0;j<3;j++){
        int n = rand()%10;
        res += num[n];
    }
    strcpy(n_bastidor,res.c_str()); //Asigna el resultado a la variable del objeto
}

void Automovil::asignarConces(int i)
{
    conces = i;
}

void Automovil::muestraConces()
{
    cout<<conces;
}


void Automovil::setColor(char i[40])
{
    strcpy(color, i);
}

void Automovil::setModelo(char i[40])
{
    strcpy(modelo, i);
}

void Automovil::setBatidor(char i[10])
{
    strcpy(color, i);
}

void Automovil::setConces(int i)
{
    conces = i;
}

void Automovil::muestra()
{
    cout<<"Bastidor: "<<n_bastidor<<endl;
    cout<<"Concesionario: "<<conces<<endl;
    cout<<"Color: "<<color<<endl;
    cout<<"Modelo: "<<modelo<<endl;
}
void Automovil::muestraBastidor()
{
    for(int i=0; i<8 ;i++){
        cout << n_bastidor[i];
    }
}

void Automovil::muestraModelo()
{
    cout<<modelo;
}

void Automovil::muestraColor()
{
    cout<<color;
}

string Automovil::getModelo()
{
    string s = modelo;
    return s;
}

string Automovil::getBastidor()
{
    string s = n_bastidor;
    return s;
}

string Automovil::getColor()
{
    string s = color;
    return s;
}

int Automovil::getConces()
{
    return conces;
}

