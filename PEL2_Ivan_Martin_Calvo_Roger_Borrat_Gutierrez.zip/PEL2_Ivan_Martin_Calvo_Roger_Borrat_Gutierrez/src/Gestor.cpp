#include "Gestor.h"
#include <string.h>
using namespace std;

Gestor::Gestor()
{
    //ctor
}

Gestor::~Gestor()
{
    //dtor
}

int Gestor::getNv()
{
    return NV;
}

int Gestor::getNs()
{
    return NS;
}

int Gestor::getNp()
{
    return NP;
}

int Gestor::getNc()
{
    return NC;
}

Cola Gestor::getColafabrica()
{
    return cola_fabrica;
}

Lista Gestor::getListaPedidos()
{
    return lista_pedidos;
}

void Gestor::inicio_simulacion()
{
    for(int i=0;i<NV;i++){
        Automovil a;
        cola_fabrica.encolar(a);
    }
    cout<<"Longitud de cola: "<<cola_fabrica.contar()<<endl;
}

void Gestor::generar_pedidos()
{
    for(int i=0; i< (NC*2*2); i++){
        Pedido p;
        lista_pedidos.insertar_porPrioridad(p);
    }
    cout<<"Longitud de lista: "<<lista_pedidos.get_longitud()<<endl;
}
void Gestor::setNv(int n)
{
        NV=n;

}

void Gestor::setNs(int n)
{
        NS=n;

}

void Gestor::avanzar_simulacion(Zona_de_Reparto* z)
{
    Automovil aut;
   if((z->camion1.contar()<NP || z->camion2.contar()<NP) && lista_pedidos.get_longitud()<1){  //Si caben mas automoviles en los camiones pero no hay suficientes vehiculos en la cola de fabrica como para poder realizar su traspaso
    cout<<"No hay suficientes automoviles en la fabrica para llenar los camiones, inicie de nuevo la simulacion"<<endl;

   }else if (z->camion1.contar()==NP && z->camion2.contar()==NP){  //Si los camiones estan llenos los pasa al almacen de zona
            z->descargar_camion();

    }
    else if(z->camion1.contar()==NP){  //Si el camion1 esta lleno carga el 2
        if(!(z->camion2.contar()==NP)){
            int c = lista_pedidos.pos_auto(cola_fabrica.inicio());
            int j  = lista_pedidos.ver_posicion(c).getConces();
             //Carga los automoviles que falten para llenarlo
                z->cargar_camion(1, &cola_fabrica, 2,j);

        }

    }
   else{
        if((z->camion1.contar()<NP)){
                int c = lista_pedidos.pos_auto(cola_fabrica.inicio());
                int j  = lista_pedidos.ver_posicion(c).getConces();
                //Carga los automoviles que falten para llenarlo
                z->cargar_camion(1, &cola_fabrica, 1,j);

        }
   }


   //cout <<cola_fabrica.contar()<<" "<<z->camion1.contar()<<" "<<z->camion2.contar()<<" "<<z->cola_zona.contar()<<endl;  //Para testeo
}

void Gestor::vaciar_Colafab()  //Vacia la cola de la fabrica
{
    while(!cola_fabrica.es_vacia()){
        cola_fabrica.desencolar();
    }
}
void Gestor::vaciar_ListaPedidos()
{
    lista_pedidos.vaciar_lista();
}

void Gestor::zona_avanzar_simulacion()
{
    int i=0;
    while(i<NS && !cola_fabrica.es_vacia() && lista_pedidos.get_longitud()>0){
        if (lista_pedidos.esta(cola_fabrica.inicio())){//Asigna una zona aleatoria
            int c = lista_pedidos.pos_auto(cola_fabrica.inicio());
            char zona = lista_pedidos.ver_posicion(c).getZona();
            switch(zona){
                case 'N':cout<<"Enviado a la zona N"<<endl;
                       avanzar_simulacion(&N);
                break;
                case 'O':cout<<"Enviado a la zona O"<<endl;
                       avanzar_simulacion(&O);
                break;
                case 'S':cout<<"Enviado a la zona S"<<endl;
                       avanzar_simulacion(&S);
                break;
                case 'E':cout<<"Enviado a la zona E"<<endl;
                       avanzar_simulacion(&E);
                break;
            }
        lista_pedidos.borrar_posicion(c);
        i++;
        }else{
            cola_fabrica.desencolar();
        }

    }lista_pedidos.todoPrior();
}

void Gestor::mostrar_Zonas_simpl(){
    cout<<"Numero de vehivulos por zonas"<<endl;
    cout<<"N: "<<N.getColaZ().contar() + N.getCamion1().contar() + N.getCamion2().contar()<< endl;
    cout<<"O: "<<O.getColaZ().contar() + O.getCamion1().contar() + O.getCamion2().contar()<< endl;
    cout<<"S: "<<S.getColaZ().contar() + S.getCamion1().contar() + S.getCamion2().contar()<< endl;
    cout<<"E: "<<E.getColaZ().contar() + E.getCamion1().contar() + E.getCamion2().contar()<< endl;
    cout<<"Lista de pedidos: "<<lista_pedidos.get_longitud()<<endl;
    cout<<"Cola de frabrica: "<<cola_fabrica.contar()<<endl;
}


void Gestor::mostrar_Zonas()
{
    cout<<"Zona de Reparto: N  \n";
    N.mostrar_Zona();
    cout<<"Zona de Reparto: S  \n";
    S.mostrar_Zona();
    cout<<"Zona de Reparto: E  \n";
    E.mostrar_Zona();
    cout<<"Zona de Reparto: O  \n";
    O.mostrar_Zona();
}

void Gestor::simulacion_completa()
{
    int n_sim=1;
    while (!(cola_fabrica.es_vacia())){
        cout<<"Paso de la simulacion numero: "<<n_sim<<endl;
        n_sim+=1;
        zona_avanzar_simulacion();

        N.mostrar_Zona();
        O.mostrar_Zona();
        S.mostrar_Zona();
        E.mostrar_Zona();

        cout<<"Los vehiculos que estan en la fabrica todavia son: "<<endl;
        cola_fabrica.muestra_Cola();

   }
}

void Gestor::pedir_coches(int n)
{

    for(int i=0; i<n ;i++){
        Pedido p;
        char mod[2];
        int c;
        char col[2];
        char z;
        bool tipo;
        char s[1];
        cout<<"Escriba el modelo deseado entre M1, M2, M3, M4, M5"<<endl;
        cin>>mod;
        cout<<"Escriba el color que deasea (C1,C2,C3)"<< endl;
        cin>>col;
        cout<<"Concesionario (entre 1 y "<< NC*NC <<")"<<endl;
        cin>>c;
        cout<<"Zona a la que se quiere enviar (N, S, O, E)"<<endl;
        cin>>z;
        cout<<"Prioridad (S/N): "<<endl;
        cin>>s;
        if ((strcmp(s,"S"))==0){
            tipo = true;
        }else{
            tipo = false;
        }
        p.setModelo(mod);
        p.setColor(col);
        p.setConces(c);
        p.setZona(z);
        p.setTipo(tipo);
        lista_pedidos.insertar_porPrioridad(p);



    }
}

void Gestor::generar_automoviles_ModCol()
{
    string c[3] = {"C1","C2","C3"};
    string k[5] = {"M1","M2","M3", "M4", "M5"};
    for(int r; r < NV ; r++){
        for(int i = 0; i<3 ; i++){
            for(int j = 0; j<5 ; j++){
                Automovil p;
                p.setColor((char*)c[i].c_str());
                p.setModelo((char*)k[j].c_str());
                cola_fabrica.encolar(p);
            }
        }
    }
    cout<<"Longitud de cola: "<<cola_fabrica.contar()<<endl;
}

void Gestor::mostrar_pedidos()
{
    lista_pedidos.muestra_Lista();
}

void Gestor::mostrar_ColaF()
{
    cola_fabrica.muestra_Cola();
}

void Gestor::auto_por_teclado()
{
    arbol.auto_por_teclado();
    arbol.verInOrden();
}

void Gestor::zona_a_arbol(char z)
{
    switch(z){
        case 'N':cout<<"Pasando de la zona N"<<endl;
            while(!N.getColaZ().es_vacia()){
                arbol.pasar_a_arbol(N.getColaZ().inicio(), 'N');
                N.desencolar();
            }
        break;
        case 'O':cout<<"Pasando de la zona O"<<endl;
            while(!O.getColaZ().es_vacia()){
                arbol.pasar_a_arbol(O.getColaZ().inicio(), 'O');
                O.getColaZ().desencolar();
            }
        break;
        case 'S':cout<<"Pasando de la zona S"<<endl;
            while(!S.getColaZ().es_vacia()){
                arbol.pasar_a_arbol(S.getColaZ().inicio(), 'S');
                S.getColaZ().desencolar();
            }
        break;
        case 'E':cout<<"Pasando de la zona E"<<endl;
            while(!E.getColaZ().es_vacia()){
                arbol.pasar_a_arbol(E.getColaZ().inicio(), 'E');
                E.getColaZ().desencolar();
            }
        break;
    }
}


void Gestor::zonas_a_arbol()
{
    while(!N.getColaZ().es_vacia()){
        Automovil a = N.getColaZ().inicio();
        arbol.pasar_a_arbol(a, 'N');
        N.desencolar();
    }
    while(!S.getColaZ().es_vacia()){
        Automovil a = S.getColaZ().inicio();
        arbol.pasar_a_arbol(a, 'S');
        S.desencolar();
    }
    while(!O.getColaZ().es_vacia()){
        Automovil a = O.getColaZ().inicio();
        arbol.pasar_a_arbol(a, 'O');
        O.desencolar();
    }
    while(!E.getColaZ().es_vacia()){
        Automovil a = E.getColaZ().inicio();
        arbol.pasar_a_arbol(a, 'E');
        E.desencolar();
    }
}


void Gestor::mostrarAbb()
{
    arbol.verConces_p();
}

void Gestor::mostrar_conces(int e)
{
    arbol.buscar_mostrar(e);
}

void Gestor::mostrar_por_bastidor(char i[10])
{
    if(!arbol.esta_por_bastidor_p(i)){
        cout<<"No existe ese bastidor"<<endl;
    }
}

void Gestor::borrado_mod(char i[3])
{
    arbol.borrar_mod_p(i);
    //arbol.borrar_vacios_p();
}
