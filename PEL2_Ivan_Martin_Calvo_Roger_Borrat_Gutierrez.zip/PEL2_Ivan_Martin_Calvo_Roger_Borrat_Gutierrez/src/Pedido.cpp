#include "Pedido.h"
#include "Gestor.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <time.h>

using namespace std;

Pedido::Pedido()
{
    asignarModelo();
    asignarColor();
    asignarConces();
    asignarZona();
    asignarTipo();
}

Pedido::~Pedido()
{
    //dtor
}


void Pedido::asignarModelo()
{
    int n = rand()%5;
    switch (n) {
        case 0: strcpy(modelo,"M1");
        break;
        case 1: strcpy(modelo,"M2");
        break;
        case 2: strcpy(modelo,"M3");
        break;
        case 3: strcpy(modelo,"M4");
        break;
        case 4: strcpy(modelo,"M5");
        break;
        }

}

char Pedido::getZona()
{
    return zona;
}

void Pedido::asignarZona()
{
    int n = rand()%4;
    switch (n) {
        case 0: zona = 'N';
        break;
        case 1: zona = 'O';
        break;
        case 2: zona = 'S';
        break;
        case 3: zona = 'E';
        break;
        }

}

void Pedido::asignarTipo()
{
    int n = rand()%2;
    switch (n) {
        case 0: tipo = true;
        break;
        case 1: tipo = false;
        break;
        }

}


void Pedido::asignarColor()
{
    int n = rand()%3;
    switch (n) {
        case 0: strcpy(color,"C1");
        break;
        case 1: strcpy(color,"C2");
        break;
        case 2: strcpy(color,"C3");
        break;
        }


}

void Pedido::asignarConces()
{
    Gestor g;
    int n = 1 + rand()%(g.getNc()*g.getNc());
    conces = n;
}

void Pedido::setColor(char i[2])
{
    strcpy(color, i);
}

void Pedido::setModelo(char i[2])
{
    strcpy(modelo, i);
}

void Pedido::setConces(int n)
{
    conces = n;
}

void Pedido::setZona(char i)
{
    zona = i;
}

int Pedido::getConces()
{
    return conces;
}
void Pedido::setTipo(bool t)
{
    tipo = t;
}
void Pedido::muestraConces()
{
    cout<<conces;
}

void Pedido::muestra()
{
    cout<<conces<<endl;
    cout<<color<<endl;
    cout<<modelo<<endl;
}

void Pedido::muestraModelo()
{
    cout<<"Modelo: " <<modelo;
}

void Pedido::muestraColor()
{
    cout<<"Color: "<<color;
}

void Pedido::muestraZona()
{
    cout<<"Zona: "<<zona;
}

void Pedido::muestraTipo()
{
    if(tipo){
        cout<<"Prioritario";
    }else{
        cout<<"No Prioritario";
    }
}
bool Pedido::getTipo()
{
    return tipo;
}

string Pedido::getModelo()
{
    string s = modelo;
    return s;
}

string Pedido::getColor()
{
    string s = color;
    return s;
}

void Pedido::volverPrior()
{
    tipo = true;
}
