#include "NodoABB.h"

NodoABB::NodoABB(Concesionario n, NodoABB *izq, NodoABB *der)
{
    //ctor
    c = n;
    hi=izq;
    hd=der;
}

NodoABB::~NodoABB()
{
    //dtor
}
