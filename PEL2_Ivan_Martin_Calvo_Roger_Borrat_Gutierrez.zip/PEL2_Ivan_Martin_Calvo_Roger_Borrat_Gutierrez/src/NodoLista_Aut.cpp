#include "NodoLista_Aut.h"

NodoLista_Aut::NodoLista_Aut(Automovil e, NodoLista_Aut *sig)
{
            elemento = e;
            siguiente = sig;
}

NodoLista_Aut::~NodoLista_Aut()
{
    //dtor
}
