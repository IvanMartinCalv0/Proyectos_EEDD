#include "ABB.h"
#include <string>
#include <iostream>
#include "Gestor.h"
using namespace std;

ABB::ABB() //crea �rbol vac�o
{
    //ctor
    raiz=NULL;
}

ABB::ABB(NodoABB *r)
{
    raiz=r;
}

ABB::ABB(Concesionario c, NodoABB *hIz, NodoABB *hDer)
{
    raiz = new NodoABB(c, NULL, NULL);
}

ABB::ABB(int nc)
{
    Concesionario c;
    string letra= "NOSE";
    int n = rand()%4;
    c.setN(nc/2);
    c.setZona(letra[n]);
    raiz = new NodoABB(c, NULL, NULL);
}

ABB::~ABB()
{
    //dtor
}

void ABB::verInOrden() { verInOrden(raiz);}
void ABB::verInOrden(NodoABB *arb) //Ver ABB en inorden
{
    if (arb) {
        verInOrden(arb->hi); //Recursion para la rama izquierda
        cout<< arb->c.getN()<<endl; //Mostrar nombre
        verInOrden(arb->hd); // Recursion para la rama derecha
    }
}

void ABB::insertar(Concesionario nombre)
{insertar(nombre, raiz);}

void ABB::insertar(Concesionario nombre, NodoABB *nodo)//En este m�todo insertamos un nombre en el ABB en orden
{
    if ((nodo->c.getN() > nombre.getN()) || (nodo->c.getN() == nombre.getN())) //Si el nombre es menor o igual al del nodo ra�z
    {
        if (nodo->hi == NULL) //Si el nodo izquierdo est� vacio entoces
        {
            NodoABB *nuevo=new NodoABB(nombre); //creo un objeto NodoABB para insertarlo en el ABB
            nodo->hi= nuevo;
        }
        else //En caso de que el nodo no estuviera vacio
        {
            insertar(nombre, nodo->hi); //insertamos en el nodo izquierdo
        }
    }else // Si el nombre es > que el nodo
        {
            if (nodo->hd == NULL) //Comprobamos si el derecho no existe
        {
            NodoABB *nuevo=new NodoABB(nombre); // Creamos un nuevo nodo en la rama derecha
            nodo->hd=nuevo;
        }
        else //si existe
        {
        insertar(nombre, nodo->hd);// insertamos el pasajero al nodo derecho
        }
    }
}

void ABB::auto_por_teclado()
{
    Automovil a;
    char bs[10];
    char col[3];
    char mod[3];
    int con;
    char z;
    cout<<"Inserte el numero de bastidor (5 letras y 3 numeros): ";  //Pide los valores necesarios al ususario
    cin>>bs;
    cout<<"Inserte el color (C1,C2,C3): ";
    cin>>col;
    cout<<"Inserte el modelo (M1,M2,M3,M4,M5): ";
    cin>>mod;
    cout<<"Inserte el numero de concesionario: ";
    cin>>con;
    cout<<"Inserte la zona (N,S,O,E): ";
    cin>>z;
    cout<<endl;
    a.setColor(col);
    a.setModelo(mod);
    a.setBatidor(bs);
    a.setConces(con);
    if (esta(con, raiz)){
        insertar_en_conces(con, a, raiz);
    }else{
        Concesionario c;
        c.setN(con); c.setZona(z); c.getLista().insertar_derecha(a); //Configura el concesionario para meterlo al arbol
        insertar(c);
    }


}

bool ABB::esta(int num_con, NodoABB *a)
{
    if(a==NULL){
        return false;
    }else if(num_con == a->c.getN()){
        return true;
    }else if (num_con < a->c.getN()){
        return esta(num_con, a->hi);
    }else{
        return esta(num_con, a->hd);
    }
}



int ABB::n_nodos_p(){n_nodos(raiz);}

int ABB::n_nodos(NodoABB *a)
{
    if(a!=NULL){
        return 1 + n_nodos(a->hd) + n_nodos(a->hi);
    }return 0;
}


void ABB::insertar_en_conces(int num_con,Automovil aut, NodoABB *a) //Inserta el Automovil en el concesionario pedido
{
    if(num_con == a->c.getN()){
        a->c.insertar_lista(aut);
    }else{
        if (num_con < a->c.getN()){
             insertar_en_conces(num_con,aut, a->hi);
        }else{
             insertar_en_conces(num_con,aut, a->hd);
        }
    }
}


void ABB::pasar_a_arbol(Automovil a, char z) //Inserta el vehiculo en el arbol teniendo en cuenta el concesionario y zona
{
    if (esta(a.getConces(), raiz)){
        Automovil i = a;
        int concesionario= a.getConces();
        insertar_en_conces(concesionario, i, raiz);
    }else{
        Automovil i = a;
        Concesionario c;
        int concesionario = a.getConces();
        c.setN(concesionario); c.setZona(z); c.insertar_lista(i);
        insertar(c);
    }
}

void ABB::verConces_p(){verConces(raiz);}

void ABB::verConces(NodoABB *arb)
{
    if (arb!=NULL) {
        verConces(arb->hi); //Recursion para la rama izquierda
        arb->c.ver_Concesionario(); //Mostrar datos del concesionario
        verConces(arb->hd); // Recursion para la rama derecha
    }
}


void ABB::borrar_vacios_p(int e){
    borrar_vacios(e, raiz, NULL);
}
void ABB::borrar_vacios(int e , NodoABB* arb, NodoABB *padre)
{
    if(!arb==NULL){
        if((arb->c.getLista().get_longitud()==0)&&(e!=5)){
            if(arb->hi==NULL && arb->hd==NULL){
                if(padre->hd->c.getN() == arb->c.getN()){
                    NodoABB *aux;
                    aux = arb;
                    arb = NULL;
                    padre->hd = arb;
                    delete(aux);
                }else{
                    NodoABB *aux;
                    aux = arb;
                    arb = NULL;
                    padre->hi = arb;
                    delete(aux);
                }
                arb = NULL;
                delete(arb);
            }else if(arb->hi==NULL){
                if(padre->hd->c.getN() == arb->c.getN()){
                    NodoABB *aux;
                    aux = arb;
                    arb = (arb->hd);
                    padre->hd = arb;
                    delete(aux);
                }else{
                    NodoABB *aux;
                    aux = arb;
                    arb = (arb->hd);
                    padre->hi = arb;
                    delete(aux);
                }
            }else if(arb->hd==NULL){
                if(padre->hd->c.getN() == arb->c.getN()){
                    NodoABB *aux;
                    aux = arb;
                    arb = (arb->hi);
                    padre->hd = arb;
                    delete(aux);
                }else{
                    NodoABB *aux;
                    aux = arb;
                    arb = (arb->hi);
                    padre->hi = arb;
                    delete(aux);
                }
            }else{
                NodoABB* maxi = maximo(arb->hi);
                borrar_vacios(maxi->c.getN(),maxi->hd, maxi);
                padre->hd = maxi->hd;
                arb = maxi->hd;
                delete(maxi);
            }
        }else{
            if(e<arb->c.getN()){
                borrar_vacios(e,arb->hi, arb);

            }else if (e>arb->c.getN()){
                borrar_vacios(e,arb->hd, arb);
            }
        }
    }
}



NodoABB* ABB::maximo(NodoABB *arb)
{
    if(arb->hd->hd==NULL){
      return arb;
    }else{
        return maximo(arb->hd);
    }
}

void ABB::verConcesDado(NodoABB *arb, int i) //Dado un concesionario muestra todos sus vehiculos
{
    if (arb!=NULL) {
        int m = arb->c.getN();
        if(i == m){
            arb->c.ver_Concesionario(); //Mostrar datos del concesionario
        }else if(i < m){
            verConcesDado(arb->hi,i); //Recursion para la rama izquierda
        }else{
            verConcesDado(arb->hd,i); // Recursion para la rama derecha
        }
    }
}

void ABB::buscar_mostrar(int i)
{
    if(esta(i, raiz)){
        verConcesDado(raiz,i);
    }else{
        cout<<"No existe dicho concesionario"<<endl;
    }
}


bool ABB::esta_por_bastidor_p(char j[10]){return esta_por_bastidor(j,raiz);}

bool ABB::esta_por_bastidor(char j[10], NodoABB* a)
{
    bool s;
    if(a==NULL){
        return false;
    }else if(a->c.getLista().esta_por_bastidor(j)){
        cout<<"El Bastidor pertenece al concesionario "<<a->c.getN()<<" de la zona "<<a->c.getZona()<<endl; //Muestra los datos si coincide con el bastidor
        return true;
    }else{
        s = esta_por_bastidor(j,a->hi);
        if(!s){
           s = esta_por_bastidor(j,a->hd);
        }
        return s;
    }
}

void ABB::borrar_mod_p(char k[3]){borrar_mod(k,raiz);}

void ABB::borrar_mod(char k[3], NodoABB *a)
{
    if(a!=NULL){
        a->c.borrar_mod_deLista(k);
        /*if(a->c.getLista().get_longitud()==0){
            borrar_vacios_p(a->c.getN());
        }*/
        borrar_mod(k, a->hi);
        borrar_mod(k, a->hd);
    }
}

