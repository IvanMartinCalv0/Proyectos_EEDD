#ifndef LISTA_AUT_H
#define LISTA_AUT_H
#include "NodoLista_Aut.h"
#include "Automovil.h"

class Lista_Aut
{
    public:
        Lista_Aut();
        virtual ~Lista_Aut();
        int get_longitud();
        void insertar_derecha(Automovil);
        void insertar_izquierda(Automovil);
        void insertar_enPosicion(int, Automovil);
        void insertar_porPrioridad(Automovil);
        bool es_vacia();
        Automovil ver_primero();
        Automovil ver_ultimo();
        Automovil ver_posicion(int);
        void borrar_izquierda();
        void borrar_posicion(int);
        void vaciar_lista();
        void mostrar(); //Muestra los datos de la lista
        bool esta_por_bastidor(char[10]); //Determina si un vehiculo esta dado un bastidor
        void borrado_m(char[3], int); //elimina el modelo dado


    private:
        NodoLista_Aut * primero;
        NodoLista_Aut * ultimo;
        int longitud;
};

#endif // LISTA_AUT_H
