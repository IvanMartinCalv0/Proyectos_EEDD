#ifndef NODOLISTA_H
#define NODOLISTA_H
#include <iostream>
#include "Pedido.h"

using namespace std;

class NodoLista
{
    friend class Lista;
    private:
        NodoLista *siguiente;
        Pedido elemento;
    public:
        NodoLista(Pedido e, NodoLista *sig = NULL);
        ~NodoLista();


};

#endif // NODOLISTA_H
