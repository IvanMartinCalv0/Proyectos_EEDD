#ifndef CONCESIONARIO_H
#define CONCESIONARIO_H
#include "Lista_Aut.h"
#include "Automovil.h"

class Concesionario
{
    public:
        Concesionario();
        virtual ~Concesionario();
        void setN(int);
        void setZona(char);
        int getN();
        char getZona();
        Lista_Aut getLista();
        void ver_Concesionario(); //muestra los datos del concesionario
        void insertar_lista(Automovil);//A�ade el automovil a la lista
        void borrar_mod_deLista(char[3]);
        void setLista(Lista_Aut l);


    private:
        int n;
        Lista_Aut lista;
        char zona;
};

#endif // CONCESIONARIO_H
