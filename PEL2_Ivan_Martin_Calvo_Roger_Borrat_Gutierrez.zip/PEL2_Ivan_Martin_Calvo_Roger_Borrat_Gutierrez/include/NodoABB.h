#ifndef NODOABB_H
#define NODOABB_H
#include "Concesionario.h"
#include <stdio.h>
using namespace std;

class NodoABB
{
    friend class ABB;
    public:
        NodoABB(Concesionario nom, NodoABB *izq=NULL, NodoABB *der=NULL);
        ~NodoABB();

    private:
        Concesionario c;
        NodoABB *hi, *hd;
};

#endif // NODOABB_H

