#ifndef ZONA_DE_REPARTO_H
#define ZONA_DE_REPARTO_H
#include "Cola.h"
#include "Pila.h"
#include "Lista.h"

class Zona_de_Reparto
{
    friend class Gestor;
    public:
        Zona_de_Reparto();
        virtual ~Zona_de_Reparto();
        Cola getColaZ();
        Pila getCamion1();
        Pila getCamion2();
        void mostrar_Zona();  //Muestra los vehiculos de la zona de reparto
        void cargar_camion(int, Cola*, int, int);//Carga n automoviles en el camion
        void descargar_camion();//Descarga elcamion en la cola de zona
        void desencolar();
        void encolar(Automovil);

    private:
        Cola cola_zona;
        Pila camion1;
        Pila camion2;

};

#endif // ZONA_DE_REPARTO_H
