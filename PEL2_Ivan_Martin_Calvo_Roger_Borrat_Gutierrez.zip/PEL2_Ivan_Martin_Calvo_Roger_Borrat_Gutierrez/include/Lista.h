#ifndef LISTA_H
#define LISTA_H
#include "NodoLista.h"
#include "Pedido.h"
#include "Automovil.h"

class Lista
{
    private:
        NodoLista * primero;
        NodoLista * ultimo;
        int longitud;
    public:
        Lista();
        ~Lista();
        int get_longitud();
        void insertar_derecha(Pedido);
        void insertar_izquierda(Pedido);
        void insertar_enPosicion(int, Pedido);
        void insertar_porPrioridad(Pedido);
        bool es_vacia();
        Pedido ver_primero();
        Pedido ver_ultimo();
        Pedido ver_posicion(int);
        void borrar_izquierda();
        void borrar_posicion(int);
        void vaciar_lista();
        bool esta(Automovil);
        Pedido buscar_auto(Automovil); //Devuelve el pedido que coincida con los datos del automovil pasado
        int pos_auto(Automovil);
        void muestra_Lista();
        int contarPrior();//Determina el numero de pedidos prioitarios
        void todoPrior(); //hace todos los pedidos prioritarios

};

#endif // LISTA_H
