#ifndef GESTOR_H
#define GESTOR_H
#include "Automovil.h"
#include "Cola.h"
#include "Zona_de_Reparto.h"
#include "Pila.h"
#include "ABB.h"
#include "Lista.h"

class Gestor
{
    friend class Automovil;
    public:
        Gestor();
        virtual ~Gestor();
        int getNv();
        int getNs();
        int getNp();
        int getNc();
        void setNv(int);  //Asigna el numero de vehiculos
        void setNs(int);  //Asigna el numero de vehiculos que se sacan de la cola de fabrica
        void inicio_simulacion();  //Comienza la simulacion
        Cola getColafabrica();
        Lista getListaPedidos();
        Zona_de_Reparto cargar_camiones();
        void avanzar_simulacion(Zona_de_Reparto*);  //Avanza un paso de la simulacion
        void vaciar_Colafab();  //Vacia la cola de fabrica
        void vaciar_ListaPedidos();
        void zona_avanzar_simulacion(); //Selecciona de forma aleatoria la zona a la que se envian los vehiculos
        void simulacion_completa(); //Realiza la simulacion hasta el final
        void mostrar_Zonas();
        void generar_pedidos(); //genera los pedidos aleatoriamente
        void pedir_coches(int); //pide los datos para hacer un pedido
        void mostrar_pedidos();
        void mostrar_Zonas_simpl();
        void mostrar_ColaF(); // muestra la cola de fabrica
        void generar_automoviles_ModCol(); //Genera todas las combinaciones posibles de color y modelo n veces
        void auto_por_teclado(); //Introduce un automovil en el arbol
        void zona_a_arbol(char); //pasa los automoviles de una cola de zona al arbol
        void zonas_a_arbol(); //pasa los automoviles de las colas de zona al arbol
        void mostrarAbb(); //Muestra los datos de todo el abb
        void mostrar_conces(int); //Muestra los vehiculos de cada concesionario
        void mostrar_por_bastidor(char[10]); //Dado un bastidor muestra su concesionario y zona
        void borrado_mod(char[3]);

    private:
        //Constantes
        int NV=20, NS=5,NP=10, NC=10;
        Cola cola_fabrica;
        Lista lista_pedidos;
        Zona_de_Reparto N;
        Zona_de_Reparto O;
        Zona_de_Reparto S;
        Zona_de_Reparto E;
        ABB arbol = ABB(NC);

};

#endif // GESTOR_H
