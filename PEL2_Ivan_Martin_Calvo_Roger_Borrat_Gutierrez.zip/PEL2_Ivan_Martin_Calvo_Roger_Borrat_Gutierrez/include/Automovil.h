#ifndef AUTOMOVIL_H
#define AUTOMOVIL_H
#include <iostream>
using namespace std;

class Automovil
{

    public:
        Automovil();
        virtual ~Automovil();
        void asignarColor(); //Asigna el color de forma aleatoria
        void asignarModelo();  //Asigna el modelo de forma aleatoria
        void asignarConces(int);  //Asigna el concesionario de forma aleatoria
        void asignarBastidor();  //Asigna el bastidor de forma aleatoria
        string getModelo();
        int getConces();
        string getColor();
        string getBastidor();
        void setColor(char[40]);
        void setModelo(char[40]);
        void setBatidor(char[10]);
        void setConces(int);
        void muestra();  //Muestra todos los datos del vehiculo para poder hacer testeos
        void muestraColor(); //Muestra el color
        void muestraModelo(); //Muestra el Modelo
        void muestraBastidor();  //Muestra el bastidor
        void muestraConces();  //Muestra el concesionario

    private:
        int conces;
        char n_bastidor[10];
        char modelo[40];
        char color[40];

};

#endif // AUTOMOVIL_H
