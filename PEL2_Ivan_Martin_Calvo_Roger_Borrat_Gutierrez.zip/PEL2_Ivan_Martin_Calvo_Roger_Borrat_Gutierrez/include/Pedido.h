#ifndef PEDIDO_H
#define PEDIDO_H
#include <iostream>
using namespace std;

class Pedido
{
    public:
        Pedido();
        virtual ~Pedido();
        void asignarColor(); //Asigna el color de forma aleatoria
        void asignarModelo();  //Asigna el modelo de forma aleatoria
        void asignarConces();  //Asigna el concesionario de forma aleatoria
        void asignarZona();  //Asigna la zona de forma aleatoria
        void asignarTipo();  //Asigna el tipo de forma aleatoria
        void setColor(char[3]);
        void setModelo(char[3]);
        void setConces(int);
        void setZona(char);
        void setTipo(bool);
        bool getTipo();
        string getModelo();
        string getColor();
        char getZona();
        int getConces();
        void volverPrior();
        void muestra();  //Muestra todos los datos del vehiculo para poder hacer testeos
        void muestraColor(); //Muestra el color
        void muestraModelo(); //Muestra el Modelo
        void muestraConces();  //Muestra el concesionario
        void muestraZona();
        void muestraTipo();

    private:
        int conces;
        char zona;
        bool tipo;
        char modelo[3] = "  "; //Se ponen vacios para evitar ciertos problemas observados al utilizar strcpy();
        char color[3] = "  ";
};

#endif // PEDIDO_H
