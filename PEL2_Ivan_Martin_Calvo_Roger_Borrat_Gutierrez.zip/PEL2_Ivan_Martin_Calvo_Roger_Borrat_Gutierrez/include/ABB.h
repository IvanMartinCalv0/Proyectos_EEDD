#ifndef ABB_H
#define ABB_H
#include "NodoABB.h"
#include "Concesionario.h"


class ABB
{
    //friend class Gestor;
    public:
        ABB();
        ABB(NodoABB *r);
        ABB(Concesionario c, NodoABB *hIz=NULL , NodoABB *hDer = NULL);
        ABB(int n);
        ~ABB();
        void verInOrden(); //Muestra el arbol en inorden
        void insertar(Concesionario nom); //A�ade un concesionario al arbol
        void auto_por_teclado(); //Pide los datos al usuario para que pueda insertar  el vehiculo al arbol
        bool esta(int, NodoABB*); //Determina si un concesionario esta en el arbol segun su numero
        void insertar_en_conces(int, Automovil, NodoABB*);
        void pasar_a_arbol(Automovil, char);
        void verConces_p();//Muestra los datos de los concesionarios en orden segun el numero asignado
        int n_nodos_p(); //Determina el numero de concesionarios que hay, utilizado para testeo
        void borrar_vacios_p(int);
        void buscar_mostrar(int); //Muestra el contenido de un concesionario
        bool esta_por_bastidor_p(char[10]);//Determina si un vehiculo esta en el arbol e imprime su concesionario y zona
        void borrar_mod_p(char[3]); //Borra los Automoviles que tengan el modelo que se envie de parametro
        NodoABB* maximo(NodoABB*);

    private:
        void borrar_mod(char[3], NodoABB*);
        bool esta_por_bastidor(char[10], NodoABB*);
        void borrar_vacios(int, NodoABB*, NodoABB*);
        int n_nodos(NodoABB*);
        void verConces(NodoABB *arb);
        void verConcesDado(NodoABB *arb,int);
        NodoABB *raiz;
        void verInOrden(NodoABB *arb);
        void insertar(Concesionario nom, NodoABB *nodo);

};

#endif // ABB_H
