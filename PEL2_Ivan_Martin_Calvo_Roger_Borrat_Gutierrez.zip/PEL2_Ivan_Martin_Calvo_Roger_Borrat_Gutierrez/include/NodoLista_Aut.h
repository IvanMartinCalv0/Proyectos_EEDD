#ifndef NODOLISTA_AUT_H
#define NODOLISTA_AUT_H
#include <iostream>
#include "Automovil.h"

class NodoLista_Aut
{
    friend class Lista_Aut;
    private:
        NodoLista_Aut *siguiente;
        Automovil elemento;
    public:
        NodoLista_Aut(Automovil e, NodoLista_Aut *sig = NULL);
        ~NodoLista_Aut();
};

#endif // NODOLISTA_AUT_H
